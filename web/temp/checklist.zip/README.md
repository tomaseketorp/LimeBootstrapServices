#Checklist
The checklist is a very simpel checklist. It can be used in any case you need someting to keep track of things that should be done.
You can eaither generate a checklist based on a template or let the user add their own tasks or even both!

